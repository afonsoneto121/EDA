package br.ufc.quixada.eda.util;

public interface EDAConstants {
	String caminhoPasta = System.getProperty("user.dir") + "/Instancias/ListaPrioridades/";
}
