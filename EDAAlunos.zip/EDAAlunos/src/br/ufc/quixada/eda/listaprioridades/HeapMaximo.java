package br.ufc.quixada.eda.listaprioridades;

import java.util.List;

/**
 * Implementa a lista de prioridade usando Heap Maximo.
 * @author fabio
 *
 */
public class HeapMaximo {
	private int nMaximo = 0;
	private int vetor[] = null;
	private int n = 0;
	
	public HeapMaximo(int Nmaximo){
		nMaximo = Nmaximo;
		vetor = new int[Nmaximo];
	}
	
	private void subir(int i){
	}
	
	private void descer(int i){
	}
	
	public void contruir(List<Integer> entrada){
	}
	
	public int getMaximaPrioridade(){
		return 0;
	}
	
	public int remove(){
		return 0;
	}	
	
	public void inserir(int prioridade){
	}
	
	public void alterarPrioridade(int prioridade, int novaPrioridade){		
	}	
}
